UPDATE `hb_configuration` SET `value` = '3.1.0' WHERE `setting`= 'Version';
##########
ALTER TABLE `hb_tickets`  ADD COLUMN `lastupdate` DATETIME NOT NULL AFTER `lastreply`;
##########
REPLACE INTO `hb_configuration` VALUES ('SEOUrlMode','index.php?/');
##########
ALTER TABLE `hb_accounts` ADD `parent_id` INT( 11 ) NOT NULL  DEFAULT '0' AFTER `product_id`;
##########
UPDATE `hb_client_access` SET `status` = 'Inactive' WHERE `status` = 'Pending';
##########
UPDATE `hb_email_templates` SET `plain`='1' WHERE `tplname` IN ('Cron Results','Details:Password Reset','Ticket:By Admin','EnomSSL:Renewed Certificate','EnomSSL:New Certificate','EnomSSL:Configure Certificate','Domain:Registered');
##########
ALTER TABLE `hb_client_access` CHANGE `status` `status` ENUM( 'Active', 'Inactive', 'Closed') NOT NULL DEFAULT 'Active';
##########
CREATE TABLE `hb_cron_tasks` (
 `task` varchar(25) collate utf8_bin NOT NULL,
 `lastrun` DATETIME NOT NULL,
 `status` tinyint(1) NOT NULL,
 PRIMARY KEY  (`task`),
 KEY `status` (`status`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
##########
DELETE FROM `hb_cron_profiles` WHERE `name`='hourlyUpdate' AND `configuration`='a:1:{i:0;s:12:"hourlyUpdate";}';
##########
INSERT INTO `hb_cron_profiles` (`id`, `name`, `description`, `run_every`, `run_every_time`, `configuration`, `last_run`, `results`) VALUES
('', 'meteredBillingUpdate', 'meteredBillingUpdate', 'Run', '1200', 'a:1:{i:0;s:20:"meteredBillingUpdate";}', '0000-00-00 00:00:00', '');
##########
ALTER TABLE `hb_automation_settings` DROP PRIMARY KEY , ADD PRIMARY KEY ( `item_id` , `type` , `setting` ( 29 ) ) ;
##########
CREATE TABLE `hb_email_assign` (
 `id` int(11) NOT NULL,
 `rel` enum('Product','Addon') NOT NULL default 'Product',
 `event` varchar(64) NOT NULL,
 `email_id` int(11) NOT NULL,
 `options` text NULL,
 PRIMARY KEY  (`id`,`rel`,`event`),
 KEY `email_id` (`email_id`)
)  ENGINE=MyISAM DEFAULT CHARSET=utf8;
##########
CREATE TABLE `hb_tickets_notes` (
	`id` INT(11) NOT NULL auto_increment,
	`ticket_id` INT(11) NOT NULL,
	`admin_id` INT(11) NOT NULL,
	`date` DATETIME NOT NULL,
	`note` text NOT NULL,
 	PRIMARY KEY  (`id`),
 	KEY `ticket_id` (`ticket_id`),
 	KEY `admin_id` (`admin_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
##########
INSERT INTO hb_tickets_notes (`id`, `ticket_id`, `admin_id`, `date`, `note`) SELECT NULL, t.id, TRIM( '$' FROM TRIM( '|' FROM SUBSTRING_INDEX(d.assigned_admins, '$', 2))), GREATEST(t.lastupdate, t.date), t.notes FROM hb_tickets t 
JOIN hb_ticket_departments d ON d.id=t.dept_id WHERE notes!='';
##########
ALTER TABLE `hb_tickets`  CHANGE COLUMN `notes` `notes` INT NOT NULL AFTER `priority`;
##########
ALTER TABLE `hb_config_upgrades` ADD `old_qty` INT( 11 ) NOT NULL AFTER `new_config_id`;
##########
INSERT INTO `hb_email_assign` (`id`,`rel`,`event`,`email_id`,`options`) SELECT `id`,`rel`,  'AfterModuleTerminate' as `event` ,`terminate_email_id`,'' as `options` FROM hb_common WHERE `rel`='Product';
##########
INSERT INTO `hb_email_assign` (`id`,`rel`,`event`,`email_id`,`options`) SELECT `id`,`rel`,  'ProductAccountCreated' as `event` ,`welcome_email_id`,'' as `options` FROM hb_common WHERE `rel`='Product';
##########
INSERT INTO `hb_email_assign` (`id`,`rel`,`event`,`email_id`,`options`) SELECT `id`,`rel`,  'SuspendAccount' as `event` ,`suspend_email_id`,'' as `options` FROM hb_common WHERE `rel`='Product';
##########
INSERT INTO `hb_email_assign` (`id`,`rel`,`event`,`email_id`,`options`) SELECT `id`,`rel`,  'UnsuspendAccount' as `event` ,`unsuspend_email_id`,'' as `options` FROM hb_common WHERE `rel`='Product';
##########
INSERT INTO `hb_email_assign` (`id`,`rel`,`event`,`email_id`,`options`) SELECT `id`,`rel`, 'TerminateAddon' as `event` ,`terminate_email_id`, '' as `options` FROM hb_common WHERE `rel`='Addon';
##########
INSERT INTO `hb_email_assign` (`id`,`rel`,`event`,`email_id`,`options`) SELECT `id`,`rel`,  'AddonActivation' as `event` ,`welcome_email_id`,'' as `options` FROM hb_common WHERE `rel`='Addon';
##########
INSERT INTO `hb_email_assign` (`id`,`rel`,`event`,`email_id`,`options`) SELECT `id`,`rel`,  'SuspendAddon' as `event` ,`suspend_email_id`,'' as `options` FROM hb_common WHERE `rel`='Addon';
##########
INSERT INTO `hb_email_assign` (`id`,`rel`,`event`,`email_id`,`options`) SELECT `id`,`rel`,  'AddonUnsuspension' as `event` ,`unsuspend_email_id`,'' as `options` FROM hb_common WHERE `rel`='Addon';
##########
INSERT INTO `hb_email_assign` (`id`,`rel`,`event`,`email_id`,`options`) SELECT `product_id`, 'Product' as `rel`,  'AfterRegistrarRegistration' as `event` ,`email_registered`,'' as `options` FROM `hb_domain_prices`;
##########
INSERT INTO `hb_email_assign` (`id`,`rel`,`event`,`email_id`,`options`) SELECT `product_id`, 'Product' as `rel`,  'AfterRegistrarTransfer' as `event` ,`email_transfered`,'' as `options` FROM `hb_domain_prices`;
##########
INSERT INTO `hb_email_assign` (`id`,`rel`,`event`,`email_id`,`options`) SELECT `product_id`, 'Product' as `rel`,  'AfterRegistrarRenewal' as `event` ,`email_renewed`,'' as `options` FROM `hb_domain_prices`;
##########
INSERT INTO `hb_email_assign` (`id`,`rel`,`event`,`email_id`,`options`) SELECT `product_id`, 'Product' as `rel`,  'expiringDomain' as `event` ,`email_reminder`,'' as `options` FROM `hb_domain_prices`;
##########
ALTER TABLE `hb_common`
  DROP `welcome_email_id`,
  DROP `suspend_email_id`,
  DROP `unsuspend_email_id`,
  DROP `terminate_email_id`;
##########
ALTER TABLE `hb_domain_prices`
  DROP `email_registered`,
  DROP `email_transfered`,
  DROP `email_renewed`,
  DROP `email_reminder`;
##########
ALTER TABLE `hb_common` CHANGE `paytype` `paytype` ENUM( 'Free', 'Once', 'Regular', 'Metered' ) NOT NULL ;
##########
ALTER TABLE `hb_common`  ADD COLUMN `p4_setup` DECIMAL(10,2) NOT NULL DEFAULT '0.00' AFTER `t_setup`,  ADD COLUMN `p5_setup` DECIMAL(10,2) NOT NULL DEFAULT '0.00' AFTER `p4_setup`,  ADD COLUMN `p4` DECIMAL(10,2) NOT NULL DEFAULT '0.00' AFTER `t`,  ADD COLUMN `p5` DECIMAL(10,2) NOT NULL DEFAULT '0.00' AFTER `p4`;
##########
REPLACE INTO `hb_language_locales` (`language_id`,`section`,`keyword`,`value`)
SELECT id, 'global', 'Quadrennially','Quadrennially' FROM hb_language WHERE target='admin';
##########
REPLACE INTO `hb_language_locales` (`language_id`,`section`,`keyword`,`value`)
SELECT id, 'global', 'Quinquennially','Quinquennially' FROM hb_language WHERE target='admin';
##########
REPLACE INTO `hb_language_locales` (`language_id`,`section`,`keyword`,`value`)
SELECT id, 'global', 'p4','Quadrennially' FROM hb_language WHERE target!='admin';
##########
REPLACE INTO `hb_language_locales` (`language_id`,`section`,`keyword`,`value`)
SELECT id, 'global', 'p5','Quinquennially' FROM hb_language WHERE target!='admin';
##########
ALTER TABLE `hb_ticket_departments`  DROP COLUMN `adminreply`;
##########
DROP TABLE `hb_hourly_exceptions`;
##########
CREATE TABLE `hb_api_access` (
 `id` int(11) NOT NULL auto_increment,
 `api_id` varchar(20) NOT NULL,
 `api_key` varchar(20) NOT NULL,
 `ip` varchar(64) NOT NULL,
 PRIMARY KEY  (`id`),
 KEY `api_id` (`api_id`,`api_key`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
##########
CREATE TABLE `hb_api_log` (
 `id` int(11) NOT NULL auto_increment,
 `api_id` varchar(20) NOT NULL,
 `date` datetime NOT NULL,
 `ip` varchar(32) NOT NULL,
 `action` text NOT NULL,
 `result` text NOT NULL,
 PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
##########
ALTER TABLE `hb_admin_access` DROP `api`;
##########
ALTER TABLE `hb_admin_log`  DROP `api`;
##########
CREATE  TABLE `hb_mettered_variables` (
  `id` INT NOT NULL AUTO_INCREMENT ,
  `product_id` INT NOT NULL ,
  `name` VARCHAR(45) NOT NULL  ,
  `variable_name` VARCHAR(45) NOT NULL ,
  `unit_name` VARCHAR(45) NOT NULL ,
  `cycle` ENUM('Account','Hourly','Monthly') NOT NULL DEFAULT 'Account',
  `scheme` ENUM ('unit','volume','tiered','stairstep') NOT NULL DEFAULT 'unit',
  `options` INT NOT NULL ,
  `date_created` DATETIME NULL,
  PRIMARY KEY (`id`) ,
  INDEX `pid` (`product_id` ASC) ,
  INDEX `variable` (`variable_name` ASC)
) ENGINE = MyISAM DEFAULT CHARSET=utf8;
##########
CREATE  TABLE `hb_mettered_prices` (
  `id` INT NOT NULL AUTO_INCREMENT ,
  `variable_id` INT NOT NULL ,
  `qty` INT NOT NULL ,
  `qty_max` INT NOT NULL ,
  `price` DECIMAL(10,4) NOT NULL ,
  PRIMARY KEY (`id`) ,
  INDEX `fk_variable` (`variable_id` ASC)
) ENGINE = MyISAM DEFAULT CHARSET=utf8;
##########
CREATE  TABLE `hb_mettered_values` (
  `id` INT NOT NULL AUTO_INCREMENT ,
  `variable_id` INT NOT NULL ,
  `account_id` INT NOT NULL ,
  `date_created` DATETIME NOT NULL ,
  `date_updated` DATETIME NOT NULL ,
  `charge` DECIMAL(10,4) NOT NULL ,
  `qty` DECIMAL( 10, 2 )  NOT NULL ,
  `output` TEXT NOT NULL ,
  `rawoutput` TEXT NULL ,
  PRIMARY KEY (`id`) ,
  INDEX `fk_var` (`variable_id` ASC) ,
  INDEX `account_id` (`account_id` ASC)
 ) ENGINE = MyISAM DEFAULT CHARSET=utf8;
##########
CREATE TABLE `hb_mettered_reports` (
 `id` int(11) NOT NULL auto_increment,
 `account_id` int(11) NOT NULL,
 `variable_id` int(11) NOT NULL,
 `type` enum('Admin','Client','Log','Report','Invoice') NOT NULL default 'Log',
 `date_created` datetime NOT NULL,
 `output` text NOT NULL,
 `charge` DECIMAL(10,4) NOT NULL ,
 PRIMARY KEY  (`id`),
 KEY `account_id` (`account_id`),
 KEY `variable_id` (`variable_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
##########
ALTER TABLE `hb_categories` ADD `opconfig` TEXT NOT NULL;
##########
INSERT INTO `hb_server_groups` (`id`,`name`,`module`) SELECT '', m.modname, m.id FROM hb_modules_configuration m WHERE m.type='Domain' AND m.id IN (SELECT module FROM hb_domain_prices);   ;
##########
INSERT INTO `hb_servers` (`id`, `group_id`, `default`, `name`, `username`, `password`, `ip`, `host`, `status_url`, `ns1`, `ns2`, `ns3`, `ns4`, `ip1`, `ip2`, `ip3`, `ip4`, `max_accounts`, `default_module`, `hash`, `secure`, `enable`, `field1`, `field2`)
SELECT '' as id, g.id as grou_id, '1' as `default`, g.`name` as `name`,
'' as `username`, '' as `password`, '' as `ip`, '' as `host`, '' as `status_url`,
'' as `ns1`, '' as `ns2`, '' as `ns3`, '' as `ns4`,  '' as `ip1`,
'' as `ip2`, '' as `ip3`, '' as `ip4`, '' as `max_accounts`,  g.`module`,
 '', '', '1', '', ''
FROM hb_server_groups g WHERE `module` IN (SELECT id FROM hb_modules_configuration WHERE type='Domain');
##########
INSERT INTO `hb_configuration` (`setting`, `value`) VALUES ('DefaultPassOptions', '1;1;1;0;8'), ('VersionLatest', '3.1.0'), ('VersionLastCheck', '0');
##########
REPLACE INTO `hb_language_locales` (`language_id`,`section`,`keyword`,`value`) 
SELECT id, 'langedit', 'dir_notwriteable','Directory is not writeable, upload is impossible (%s)' FROM hb_language WHERE target='admin';
##########
REPLACE INTO `hb_language_locales` (`language_id`,`section`,`keyword`,`value`) 
SELECT id, 'langedit', 'icon_upload','Icon uploaded to \'%s\'' FROM hb_language WHERE target='admin';
##########
REPLACE INTO `hb_language_locales` (`language_id`,`section`,`keyword`,`value`) 
SELECT id, 'langedit', 'icon_format_error','Selected icon has wrong format,' FROM hb_language WHERE target='admin';
##########
REPLACE INTO `hb_language_locales` (`language_id`,`section`,`keyword`,`value`) 
SELECT id, 'langedit', 'icon_upload_error','Icon upload faild' FROM hb_language WHERE target='admin';
##########
REPLACE INTO `hb_language_locales` (`language_id`,`section`,`keyword`,`value`) 
SELECT id, 'langedit', 'add_language_faild','Adding language faild' FROM hb_language WHERE target='admin';
##########
REPLACE INTO `hb_language_locales` (`language_id`,`section`,`keyword`,`value`) 
SELECT id, 'langedit', 'empty_name','Enter a name' FROM hb_language WHERE target='admin';
##########
REPLACE INTO `hb_language_locales` (`language_id`,`section`,`keyword`,`value`) 
SELECT id, 'langedit', 'field_invalid','Invalid field' FROM hb_language WHERE target='admin';
##########
REPLACE INTO `hb_language_locales` (`language_id`,`section`,`keyword`,`value`) 
SELECT id, 'langedit', 'token_error','CSRF Token error' FROM hb_language WHERE target='admin';
##########
REPLACE INTO `hb_language_locales` (`language_id`,`section`,`keyword`,`value`) 
SELECT id, 'langedit', 'addlang_success','New language added' FROM hb_language WHERE target='admin';
##########
REPLACE INTO `hb_language_locales` (`language_id`,`section`,`keyword`,`value`) 
SELECT id, 'langedit', 'import_success','Import operation successful' FROM hb_language WHERE target='admin';
##########
REPLACE INTO `hb_language_locales` (`language_id`,`section`,`keyword`,`value`) 
SELECT id, 'langedit', 'statuschange_faild','Status change faild' FROM hb_language WHERE target='admin';
##########
REPLACE INTO `hb_language_locales` (`language_id`,`section`,`keyword`,`value`) 
SELECT id, 'langedit', 'lang_enable','Language enabled' FROM hb_language WHERE target='admin';
##########
REPLACE INTO `hb_language_locales` (`language_id`,`section`,`keyword`,`value`) 
SELECT id, 'langedit', 'lang_disable','Language disabled' FROM hb_language WHERE target='admin';
##########
REPLACE INTO `hb_language_locales` (`language_id`,`section`,`keyword`,`value`)
SELECT id, 'accounts', 'forms_upgrade_failed','Forms elements upgrade/downgrade failed' FROM hb_language WHERE target='admin';
##########
REPLACE INTO `hb_language_locales` (`language_id`,`section`,`keyword`,`value`)
SELECT id, 'accounts', 'forms_upgrade_success','Forms elements upgrade/downgrade success' FROM hb_language WHERE target='admin';
##########
REPLACE INTO `hb_language_locales` (`language_id`,`section`,`keyword`,`value`)
SELECT id, 'tickets', 'ticketnotesdeleted','Ticket notes deleted' FROM hb_language WHERE target='admin';
##########
REPLACE INTO `hb_language_locales` (`language_id`,`section`,`keyword`,`value`)
SELECT id, 'global', 'amountcredited','Client credit updated' FROM hb_language WHERE target='admin';
##########
REPLACE INTO `hb_language_locales` (`language_id`,`section`,`keyword`,`value`)
SELECT id, 'ticket', 'emptynote','Can\'t add empty note' FROM hb_language WHERE target='admin';
##########
REPLACE INTO `hb_language_locales` (`language_id`,`section`,`keyword`,`value`)
SELECT id, 'clientarea', 'onapploginlink','Access CP' FROM hb_language WHERE target!='admin';
##########
REPLACE INTO `hb_language_locales` (`language_id`,`section`,`keyword`,`value`)
SELECT id, 'global', 'loginErrorInactive','Unable to continue - your account is not active' FROM hb_language WHERE target!='admin';
##########
REPLACE INTO `hb_language_locales` (`language_id`,`section`,`keyword`,`value`)
SELECT id, 'global', 'loginErrorClosed','Unable to continue - your account has been closed' FROM hb_language WHERE target!='admin';
##########
REPLACE INTO `hb_language_locales` (`language_id`,`section`,`keyword`,`value`)
SELECT id, 'services', 'MeteredReportClient','Client: Usage Report' FROM hb_language WHERE target='admin';
##########
REPLACE INTO `hb_language_locales` (`language_id`,`section`,`keyword`,`value`)
SELECT id, 'services', 'MeteredReportAdmin','Admin: Usage Report' FROM hb_language WHERE target='admin';
##########
REPLACE INTO `hb_language_locales` (`language_id`,`section`,`keyword`,`value`)
SELECT id, 'services', 'ProductAccountCreated','Account created email' FROM hb_language WHERE target='admin';
##########
REPLACE INTO `hb_language_locales` (`language_id`,`section`,`keyword`,`value`)
SELECT id, 'services', 'AfterModuleTerminate','Account terminated email' FROM hb_language WHERE target='admin';
##########
REPLACE INTO `hb_language_locales` (`language_id`,`section`,`keyword`,`value`)
SELECT id, 'services', 'SuspendAccount','Account suspended email' FROM hb_language WHERE target='admin';
##########
REPLACE INTO `hb_language_locales` (`language_id`,`section`,`keyword`,`value`)
SELECT id, 'services', 'UnsuspendAccount','Account unsuspended email' FROM hb_language WHERE target='admin';
##########
REPLACE INTO `hb_language_locales` (`language_id`,`section`,`keyword`,`value`)
SELECT id, 'productaddons', 'TerminateAddon','Addon terminated' FROM hb_language WHERE target='admin';
##########
REPLACE INTO `hb_language_locales` (`language_id`,`section`,`keyword`,`value`)
SELECT id, 'productaddons', 'AddonActivation','Addon Activated' FROM hb_language WHERE target='admin';
##########
REPLACE INTO `hb_language_locales` (`language_id`,`section`,`keyword`,`value`)
SELECT id, 'productaddons', 'SuspendAddon','Addon Suspended' FROM hb_language WHERE target='admin';
##########
REPLACE INTO `hb_language_locales` (`language_id`,`section`,`keyword`,`value`)
SELECT id, 'productaddons', 'UnsuspendAccount','Addon Unsuspended' FROM hb_language WHERE target='admin';
##########
REPLACE INTO `hb_language_locales` (`language_id`,`section`,`keyword`,`value`)
SELECT id, 'services', 'AfterRegistrarRegistration','Domain registration succeeded' FROM hb_language WHERE target='admin';
##########
REPLACE INTO `hb_language_locales` (`language_id`,`section`,`keyword`,`value`)
SELECT id, 'services', 'AfterRegistrarTransfer','Domain transfer initiated' FROM hb_language WHERE target='admin';
##########
REPLACE INTO `hb_language_locales` (`language_id`,`section`,`keyword`,`value`)
SELECT id, 'services', 'AfterRegistrarRenewal','Domain renewal succeeded' FROM hb_language WHERE target='admin';
##########
REPLACE INTO `hb_language_locales` (`language_id`,`section`,`keyword`,`value`)
SELECT id, 'services', 'expiringDomain','Expiring domain notification' FROM hb_language WHERE target='admin';
##########
INSERT INTO `hb_language_locales` (`language_id`,`section`,`keyword`,`value`)
SELECT id, 'global', 'newVersion','Latest Version' FROM hb_language WHERE target='admin';
##########
REPLACE INTO `hb_language_locales` (`language_id`,`section`,`keyword`,`value`)
SELECT id, 'editadmins', 'full_acces','Full Privileges' FROM hb_language WHERE target='admin';
##########
REPLACE INTO `hb_language_locales` (`language_id`,`section`,`keyword`,`value`)
SELECT id, 'editadmins', 'accounting','Accounting' FROM hb_language WHERE target='admin';
##########
REPLACE INTO `hb_language_locales` (`language_id`,`section`,`keyword`,`value`)
SELECT id, 'editadmins', 'premadepriv','Pre-made privileges:' FROM hb_language WHERE target='admin';
##########
REPLACE INTO `hb_language_locales` (`language_id`,`section`,`keyword`,`value`)
SELECT id, 'editadmins', 'full_email','Full notification' FROM hb_language WHERE target='admin';
##########
REPLACE INTO `hb_language_locales` (`language_id`,`section`,`keyword`,`value`)
SELECT id, 'editadmins', 'premadesett','Pre-made settings:' FROM hb_language WHERE target='admin';
##########
REPLACE INTO `hb_language_locales` (`language_id`,`section`,`keyword`,`value`)
SELECT id, 'global', 'powerdnspanel_hosting','PowerDNS' FROM hb_language WHERE target='admin';
##########
REPLACE INTO `hb_language_locales` (`language_id`,`section`,`keyword`,`value`)
SELECT id, 'cart', 'additional_features','Additional features' FROM hb_language WHERE target!='admin';
##########
REPLACE INTO `hb_language_locales` (`language_id`,`section`,`keyword`,`value`)
SELECT id, 'services', 'wizard_slidersquaretab','Double Slider - wizard theme' FROM hb_language WHERE target='admin';
##########
REPLACE INTO `hb_language_locales` (`language_id`,`section`,`keyword`,`value`)
SELECT id, 'configuration', 'SEOUrlMode','SEO URLs settings' FROM hb_language WHERE target='admin';
##########
REPLACE INTO `hb_language_locales` (`language_id`,`section`,`keyword`,`value`)
SELECT id, 'cart', 'additional_services','Additional services' FROM hb_language WHERE target!='admin';
##########
REPLACE INTO `hb_language_locales` (`language_id`,`section`,`keyword`,`value`)
SELECT id, 'services', 'wizard_fourbox','Comparison boxes, full screen' FROM hb_language WHERE target='admin';
##########
REPLACE INTO `hb_language_locales` (`language_id`,`section`,`keyword`,`value`)
SELECT id, 'services', 'addmorefeatures','Add more feature descriptions' FROM hb_language WHERE target='admin';
##########
REPLACE INTO `hb_language_locales` (`language_id`,`section`,`keyword`,`value`)
SELECT id, 'services', 'feature','Feature' FROM hb_language WHERE target='admin';
##########
REPLACE INTO `hb_language_locales` (`language_id`,`section`,`keyword`,`value`)
SELECT id, 'logs', 'apilog','API Usage Log' FROM hb_language WHERE target='admin';
##########
REPLACE INTO `hb_language_locales` (`language_id`,`section`,`keyword`,`value`)
SELECT id, 'clientarea', 'enter_domain_name','Your domain name without \'www\' or such:' FROM hb_language WHERE target!='admin';
##########
REPLACE INTO `hb_language_locales` (`language_id`,`section`,`keyword`,`value`)
SELECT id, 'global', 'showing','Showing' FROM hb_language WHERE target='admin';
##########
REPLACE INTO `hb_language_locales` (`language_id`,`section`,`keyword`,`value`)
SELECT id, 'global', 'of','of' FROM hb_language WHERE target='admin';
##########
REPLACE INTO `hb_language_locales` (`language_id`,`section`,`keyword`,`value`)
SELECT id, 'clientarea', 'clone_zone','Clone zone content from:' FROM hb_language WHERE target!='admin';
##########
REPLACE INTO `hb_language_locales` (`language_id`,`section`,`keyword`,`value`)
SELECT id, 'clientarea', 'dnsmanagement_widget','DNS Management' FROM hb_language WHERE target!='admin';
##########
REPLACE INTO `hb_language_locales` (`language_id`,`section`,`keyword`,`value`)
SELECT id, 'clientarea', 'domainforwarding_widget', 'Domain Forwarding' FROM hb_language WHERE target!='admin';
##########
REPLACE INTO `hb_language_locales` (`language_id`,`section`,`keyword`,`value`)
SELECT id, 'clientarea', 'emailforwarding_widget', 'Email Forwarding' FROM hb_language WHERE target!='admin';
##########
REPLACE INTO `hb_language_locales` (`language_id`,`section`,`keyword`,`value`)
SELECT id, 'clientarea', 'eppcode_widget', 'Auth Info / EPP Key' FROM hb_language WHERE target!='admin';
##########
REPLACE INTO `hb_language_locales` (`language_id`,`section`,`keyword`,`value`)
SELECT id, 'clientarea', 'registernameservers_widget', 'Register Nameservers' FROM hb_language WHERE target!='admin';
##########
REPLACE INTO `hb_language_locales` (`language_id`,`section`,`keyword`,`value`)
SELECT id, 'clientarea', 'autorenew_widget', 'Auto-Renewal Options' FROM hb_language WHERE target!='admin';
##########
REPLACE INTO `hb_language_locales` (`language_id`,`section`,`keyword`,`value`)
SELECT id, 'clientarea', 'reglock_widget', 'Domain Lock Settings' FROM hb_language WHERE target!='admin';
##########
REPLACE INTO `hb_language_locales` (`language_id`,`section`,`keyword`,`value`)
SELECT id, 'clientarea', 'nameservers_widget', 'Manage Nameservers' FROM hb_language WHERE target!='admin';
##########
REPLACE INTO `hb_language_locales` (`language_id`,`section`,`keyword`,`value`)
SELECT id, 'clientarea', 'idprotection_widget', 'Manage Privacy' FROM hb_language WHERE target!='admin';
##########
REPLACE INTO `hb_language_locales` (`language_id`,`section`,`keyword`,`value`)
SELECT id, 'clientarea', 'renew_widget','Add Years / Renew' FROM hb_language WHERE target!='admin';
##########
REPLACE INTO `hb_language_locales` (`language_id`,`section`,`keyword`,`value`)
SELECT id, 'clientarea', 'bulkdomains','Any changes made here will impact following domains:' FROM hb_language WHERE target!='admin';
##########
REPLACE INTO `hb_language_locales` (`language_id`,`section`,`keyword`,`value`)
SELECT id, 'clientarea', 'withdomains','With selected domains:' FROM hb_language WHERE target!='admin';
##########
REPLACE INTO `hb_language_locales` (`language_id`,`section`,`keyword`,`value`)
SELECT id, 'global', 'phonenumber','Phone' FROM hb_language WHERE target!='admin';
##########
REPLACE INTO `hb_language_locales` (`language_id`,`section`,`keyword`,`value`)
SELECT id, 'global', 'address1','Address 1' FROM hb_language WHERE target!='admin';
##########
REPLACE INTO `hb_language_locales` (`language_id`,`section`,`keyword`,`value`)
SELECT id, 'global', 'Metered','Metered' FROM hb_language WHERE target='admin';
##########
REPLACE INTO `hb_language_locales` (`language_id`,`section`,`keyword`,`value`)
SELECT id, 'global', 'Metered','Based on usage' FROM hb_language WHERE target!='admin';
##########
REPLACE INTO `hb_language_locales` (`language_id`,`section`,`keyword`,`value`)
SELECT id, 'global', 'password2','Repeat Password' FROM hb_language WHERE target!='admin';
##########
REPLACE INTO `hb_language_locales` (`language_id`,`section`,`keyword`,`value`)
SELECT id, 'global', 'Services','Services' FROM hb_language WHERE target='admin';
##########
REPLACE INTO `hb_language_locales` (`language_id`,`section`,`keyword`,`value`)
SELECT id, 'invoices', 'paidbybalance','Credit balance' FROM hb_language WHERE target='admin';
##########
REPLACE INTO `hb_language_locales` (`language_id`,`section`,`keyword`,`value`)
SELECT id, 'configuration', 'meteredBillingUpdate','Update Metered Billing Values' FROM hb_language WHERE target='admin';
##########
REPLACE INTO `hb_language_locales` (`language_id`,`section`,`keyword`,`value`)
SELECT id, 'accounts', 'metered_usage_added','New usage has been stored' FROM hb_language WHERE target='admin';
##########
REPLACE INTO `hb_language_locales` (`language_id`,`section`,`keyword`,`value`)
SELECT id, 'security', 'length','Length' FROM hb_language WHERE target='admin';
##########
REPLACE INTO `hb_language_locales` (`language_id`,`section`,`keyword`,`value`)
SELECT id, 'security', 'password_generator','Password Generator' FROM hb_language WHERE target='admin';
##########
REPLACE INTO `hb_language_locales` (`language_id`,`section`,`keyword`,`value`)
SELECT id, 'security', 'password_generate','Generate sample password' FROM hb_language WHERE target='admin';
##########
REPLACE INTO `hb_language_locales` (`language_id`,`section`,`keyword`,`value`)
SELECT id, 'security', 'password_opt_update','Password Generator options updated' FROM hb_language WHERE target='admin';
##########
REPLACE INTO `hb_language_locales` (`language_id`,`section`,`keyword`,`value`)
SELECT id, 'security', 'new_api_access_added','New api access id/key generated' FROM hb_language WHERE target='admin';
##########
REPLACE INTO `hb_language_locales` (`language_id`,`section`,`keyword`,`value`)
SELECT id, 'security', 'api_access_removed','Selected api access id/key has been removed' FROM hb_language WHERE target='admin';
##########
REPLACE INTO `hb_language_locales` (`language_id`,`section`,`keyword`,`value`)
SELECT id, 'security', 'apiaccess','API Access' FROM hb_language WHERE target='admin';
##########
REPLACE INTO `hb_language_locales` (`language_id`,`section`,`keyword`,`value`)
SELECT id, 'security', 'apiremoveconfirm','Are you sure you wish to remove this API access details?' FROM hb_language WHERE target='admin';
##########
REPLACE INTO `hb_language_locales` (`language_id`,`section`,`keyword`,`value`)
SELECT id, 'security', 'addapiaccess','Add API access' FROM hb_language WHERE target='admin';
##########
REPLACE INTO `hb_language_locales` (`language_id`,`section`,`keyword`,`value`)
SELECT id, 'security', 'generateapiaccess','Add API access' FROM hb_language WHERE target='admin';
##########
REPLACE INTO `hb_language_locales` (`language_id`,`section`,`keyword`,`value`)
SELECT id, 'configuration', 'meteredBillingUpdate_descr','This task should be invoked every 5 minutes. Its job is to update recurring price of accounts with metered billing enabled.' FROM hb_language WHERE target='admin';
##########
REPLACE INTO `hb_language_locales` (`language_id`,`section`,`keyword`,`value`)
SELECT id, 'clientarea', 'rootpassword','Root password' FROM hb_language WHERE target!='admin';
##########
REPLACE INTO `hb_language_locales` (`language_id`,`section`,`keyword`,`value`)
SELECT id, 'global', 'show','show' FROM hb_language WHERE target!='admin';
##########
REPLACE INTO `hb_language_locales` (`language_id`,`section`,`keyword`,`value`)
SELECT id, 'services', 'metteredschemes','<b>Tiered scheme</b><br/>
                                           Every unit charge is calculated based on its own tier.<br/>
                                           i.e.: <i>1-2: $1, 3-4: $2, qtys are: 1,3; charge: 1*$1 + 3*$2</i> <br/><br/>
                                           <b>Volume scheme</b><br/>All units charge is calculated based on total count in period and related bracket.<br/>
                                           ie.: <i>1-2: $1, 3-4: $2, qtys are: 1,3; charge: 4*$2</i><br/><br/>

                                           <b>Stairstep scheme</b><br/>Total cost is calculated based on price bracket, charge is for entire bracket not certain units<br/>
                                           i.e.: <i>1-5: $1, 6-10: $2, total qty: 7, charge: $2</i>' FROM hb_language WHERE target='admin';
##########
REPLACE INTO `hb_language_locales` (`language_id`,`section`,`keyword`,`value`) SELECT id, 'countries', 'AF', 'Afghanistan' FROM hb_language;
##########
REPLACE INTO `hb_language_locales` (`language_id`,`section`,`keyword`,`value`) SELECT id, 'countries', 'AX', 'Aland Islands' FROM hb_language;
##########
REPLACE INTO `hb_language_locales` (`language_id`,`section`,`keyword`,`value`) SELECT id, 'countries', 'AL', 'Albania' FROM hb_language;
##########
REPLACE INTO `hb_language_locales` (`language_id`,`section`,`keyword`,`value`) SELECT id, 'countries', 'DZ', 'Algeria' FROM hb_language;
##########
REPLACE INTO `hb_language_locales` (`language_id`,`section`,`keyword`,`value`) SELECT id, 'countries', 'AS', 'American Samoa' FROM hb_language;
##########
REPLACE INTO `hb_language_locales` (`language_id`,`section`,`keyword`,`value`) SELECT id, 'countries', 'AD', 'Andorra' FROM hb_language;
##########
REPLACE INTO `hb_language_locales` (`language_id`,`section`,`keyword`,`value`) SELECT id, 'countries', 'AO', 'Angola' FROM hb_language;
##########
REPLACE INTO `hb_language_locales` (`language_id`,`section`,`keyword`,`value`) SELECT id, 'countries', 'AI', 'Anguilla' FROM hb_language;
##########
REPLACE INTO `hb_language_locales` (`language_id`,`section`,`keyword`,`value`) SELECT id, 'countries', 'AQ', 'Antarctica' FROM hb_language;
##########
REPLACE INTO `hb_language_locales` (`language_id`,`section`,`keyword`,`value`) SELECT id, 'countries', 'AG', 'Antigua And Barbuda' FROM hb_language;
##########
REPLACE INTO `hb_language_locales` (`language_id`,`section`,`keyword`,`value`) SELECT id, 'countries', 'AR', 'Argentina' FROM hb_language;
##########
REPLACE INTO `hb_language_locales` (`language_id`,`section`,`keyword`,`value`) SELECT id, 'countries', 'AM', 'Armenia' FROM hb_language;
##########
REPLACE INTO `hb_language_locales` (`language_id`,`section`,`keyword`,`value`) SELECT id, 'countries', 'AW', 'Aruba' FROM hb_language;
##########
REPLACE INTO `hb_language_locales` (`language_id`,`section`,`keyword`,`value`) SELECT id, 'countries', 'AU', 'Australia' FROM hb_language;
##########
REPLACE INTO `hb_language_locales` (`language_id`,`section`,`keyword`,`value`) SELECT id, 'countries', 'AT', 'Austria' FROM hb_language;
##########
REPLACE INTO `hb_language_locales` (`language_id`,`section`,`keyword`,`value`) SELECT id, 'countries', 'AZ', 'Azerbaijan' FROM hb_language;
##########
REPLACE INTO `hb_language_locales` (`language_id`,`section`,`keyword`,`value`) SELECT id, 'countries', 'BS', 'Bahamas' FROM hb_language;
##########
REPLACE INTO `hb_language_locales` (`language_id`,`section`,`keyword`,`value`) SELECT id, 'countries', 'BH', 'Bahrain' FROM hb_language;
##########
REPLACE INTO `hb_language_locales` (`language_id`,`section`,`keyword`,`value`) SELECT id, 'countries', 'BD', 'Bangladesh' FROM hb_language;
##########
REPLACE INTO `hb_language_locales` (`language_id`,`section`,`keyword`,`value`) SELECT id, 'countries', 'BB', 'Barbados' FROM hb_language;
##########
REPLACE INTO `hb_language_locales` (`language_id`,`section`,`keyword`,`value`) SELECT id, 'countries', 'BY', 'Belarus' FROM hb_language;
##########
REPLACE INTO `hb_language_locales` (`language_id`,`section`,`keyword`,`value`) SELECT id, 'countries', 'BE', 'Belgium' FROM hb_language;
##########
REPLACE INTO `hb_language_locales` (`language_id`,`section`,`keyword`,`value`) SELECT id, 'countries', 'BZ', 'Belize' FROM hb_language;
##########
REPLACE INTO `hb_language_locales` (`language_id`,`section`,`keyword`,`value`) SELECT id, 'countries', 'BJ', 'Benin' FROM hb_language;
##########
REPLACE INTO `hb_language_locales` (`language_id`,`section`,`keyword`,`value`) SELECT id, 'countries', 'BM', 'Bermuda' FROM hb_language;
##########
REPLACE INTO `hb_language_locales` (`language_id`,`section`,`keyword`,`value`) SELECT id, 'countries', 'BT', 'Bhutan' FROM hb_language;
##########
REPLACE INTO `hb_language_locales` (`language_id`,`section`,`keyword`,`value`) SELECT id, 'countries', 'BO', 'Bolivia' FROM hb_language;
##########
REPLACE INTO `hb_language_locales` (`language_id`,`section`,`keyword`,`value`) SELECT id, 'countries', 'BA', 'Bosnia And Herzegovina' FROM hb_language;
##########
REPLACE INTO `hb_language_locales` (`language_id`,`section`,`keyword`,`value`) SELECT id, 'countries', 'BW', 'Botswana' FROM hb_language;
##########
REPLACE INTO `hb_language_locales` (`language_id`,`section`,`keyword`,`value`) SELECT id, 'countries', 'BV', 'Bouvet Island' FROM hb_language;
##########
REPLACE INTO `hb_language_locales` (`language_id`,`section`,`keyword`,`value`) SELECT id, 'countries', 'BR', 'Brazil' FROM hb_language;
##########
REPLACE INTO `hb_language_locales` (`language_id`,`section`,`keyword`,`value`) SELECT id, 'countries', 'IO', 'British Indian Ocean Territory' FROM hb_language;
##########
REPLACE INTO `hb_language_locales` (`language_id`,`section`,`keyword`,`value`) SELECT id, 'countries', 'BN', 'Brunei Darussalam' FROM hb_language;
##########
REPLACE INTO `hb_language_locales` (`language_id`,`section`,`keyword`,`value`) SELECT id, 'countries', 'BG', 'Bulgaria' FROM hb_language;
##########
REPLACE INTO `hb_language_locales` (`language_id`,`section`,`keyword`,`value`) SELECT id, 'countries', 'BF', 'Burkina Faso' FROM hb_language;
##########
REPLACE INTO `hb_language_locales` (`language_id`,`section`,`keyword`,`value`) SELECT id, 'countries', 'BI', 'Burundi' FROM hb_language;
##########
REPLACE INTO `hb_language_locales` (`language_id`,`section`,`keyword`,`value`) SELECT id, 'countries', 'KH', 'Cambodia' FROM hb_language;
##########
REPLACE INTO `hb_language_locales` (`language_id`,`section`,`keyword`,`value`) SELECT id, 'countries', 'CM', 'Cameroon' FROM hb_language;
##########
REPLACE INTO `hb_language_locales` (`language_id`,`section`,`keyword`,`value`) SELECT id, 'countries', 'CA', 'Canada' FROM hb_language;
##########
REPLACE INTO `hb_language_locales` (`language_id`,`section`,`keyword`,`value`) SELECT id, 'countries', 'CV', 'Cape Verde' FROM hb_language;
##########
REPLACE INTO `hb_language_locales` (`language_id`,`section`,`keyword`,`value`) SELECT id, 'countries', 'KY', 'Cayman Islands' FROM hb_language;
##########
REPLACE INTO `hb_language_locales` (`language_id`,`section`,`keyword`,`value`) SELECT id, 'countries', 'CF', 'Central African Republic' FROM hb_language;
##########
REPLACE INTO `hb_language_locales` (`language_id`,`section`,`keyword`,`value`) SELECT id, 'countries', 'TD', 'Chad' FROM hb_language;
##########
REPLACE INTO `hb_language_locales` (`language_id`,`section`,`keyword`,`value`) SELECT id, 'countries', 'CL', 'Chile' FROM hb_language;
##########
REPLACE INTO `hb_language_locales` (`language_id`,`section`,`keyword`,`value`) SELECT id, 'countries', 'CN', 'China' FROM hb_language;
##########
REPLACE INTO `hb_language_locales` (`language_id`,`section`,`keyword`,`value`) SELECT id, 'countries', 'CX', 'Christmas Island' FROM hb_language;
##########
REPLACE INTO `hb_language_locales` (`language_id`,`section`,`keyword`,`value`) SELECT id, 'countries', 'CC', 'Cocos (Keeling) Islands' FROM hb_language;
##########
REPLACE INTO `hb_language_locales` (`language_id`,`section`,`keyword`,`value`) SELECT id, 'countries', 'CO', 'Colombia' FROM hb_language;
##########
REPLACE INTO `hb_language_locales` (`language_id`,`section`,`keyword`,`value`) SELECT id, 'countries', 'KM', 'Comoros' FROM hb_language;
##########
REPLACE INTO `hb_language_locales` (`language_id`,`section`,`keyword`,`value`) SELECT id, 'countries', 'CG', 'Congo' FROM hb_language;
##########
REPLACE INTO `hb_language_locales` (`language_id`,`section`,`keyword`,`value`) SELECT id, 'countries', 'CD', 'Congo, Democratic Republic' FROM hb_language;
##########
REPLACE INTO `hb_language_locales` (`language_id`,`section`,`keyword`,`value`) SELECT id, 'countries', 'CK', 'Cook Islands' FROM hb_language;
##########
REPLACE INTO `hb_language_locales` (`language_id`,`section`,`keyword`,`value`) SELECT id, 'countries', 'CR', 'Costa Rica' FROM hb_language;
##########
REPLACE INTO `hb_language_locales` (`language_id`,`section`,`keyword`,`value`) SELECT id, 'countries', 'CI', 'Cote D\'Ivoire' FROM hb_language;
##########
REPLACE INTO `hb_language_locales` (`language_id`,`section`,`keyword`,`value`) SELECT id, 'countries', 'HR', 'Croatia' FROM hb_language;
##########
REPLACE INTO `hb_language_locales` (`language_id`,`section`,`keyword`,`value`) SELECT id, 'countries', 'CU', 'Cuba' FROM hb_language;
##########
REPLACE INTO `hb_language_locales` (`language_id`,`section`,`keyword`,`value`) SELECT id, 'countries', 'CY', 'Cyprus' FROM hb_language;
##########
REPLACE INTO `hb_language_locales` (`language_id`,`section`,`keyword`,`value`) SELECT id, 'countries', 'CZ', 'Czech Republic' FROM hb_language;
##########
REPLACE INTO `hb_language_locales` (`language_id`,`section`,`keyword`,`value`) SELECT id, 'countries', 'DK', 'Denmark' FROM hb_language;
##########
REPLACE INTO `hb_language_locales` (`language_id`,`section`,`keyword`,`value`) SELECT id, 'countries', 'DJ', 'Djibouti' FROM hb_language;
##########
REPLACE INTO `hb_language_locales` (`language_id`,`section`,`keyword`,`value`) SELECT id, 'countries', 'DM', 'Dominica' FROM hb_language;
##########
REPLACE INTO `hb_language_locales` (`language_id`,`section`,`keyword`,`value`) SELECT id, 'countries', 'DO', 'Dominican Republic' FROM hb_language;
##########
REPLACE INTO `hb_language_locales` (`language_id`,`section`,`keyword`,`value`) SELECT id, 'countries', 'EC', 'Ecuador' FROM hb_language;
##########
REPLACE INTO `hb_language_locales` (`language_id`,`section`,`keyword`,`value`) SELECT id, 'countries', 'EG', 'Egypt' FROM hb_language;
##########
REPLACE INTO `hb_language_locales` (`language_id`,`section`,`keyword`,`value`) SELECT id, 'countries', 'SV', 'El Salvador' FROM hb_language;
##########
REPLACE INTO `hb_language_locales` (`language_id`,`section`,`keyword`,`value`) SELECT id, 'countries', 'GQ', 'Equatorial Guinea' FROM hb_language;
##########
REPLACE INTO `hb_language_locales` (`language_id`,`section`,`keyword`,`value`) SELECT id, 'countries', 'ER', 'Eritrea' FROM hb_language;
##########
REPLACE INTO `hb_language_locales` (`language_id`,`section`,`keyword`,`value`) SELECT id, 'countries', 'EE', 'Estonia' FROM hb_language;
##########
REPLACE INTO `hb_language_locales` (`language_id`,`section`,`keyword`,`value`) SELECT id, 'countries', 'ET', 'Ethiopia' FROM hb_language;
##########
REPLACE INTO `hb_language_locales` (`language_id`,`section`,`keyword`,`value`) SELECT id, 'countries', 'FK', 'Falkland Islands (Malvinas)' FROM hb_language;
##########
REPLACE INTO `hb_language_locales` (`language_id`,`section`,`keyword`,`value`) SELECT id, 'countries', 'FO', 'Faroe Islands' FROM hb_language;
##########
REPLACE INTO `hb_language_locales` (`language_id`,`section`,`keyword`,`value`) SELECT id, 'countries', 'FJ', 'Fiji' FROM hb_language;
##########
REPLACE INTO `hb_language_locales` (`language_id`,`section`,`keyword`,`value`) SELECT id, 'countries', 'FI', 'Finland' FROM hb_language;
##########
REPLACE INTO `hb_language_locales` (`language_id`,`section`,`keyword`,`value`) SELECT id, 'countries', 'FR', 'France' FROM hb_language;
##########
REPLACE INTO `hb_language_locales` (`language_id`,`section`,`keyword`,`value`) SELECT id, 'countries', 'GF', 'French Guiana' FROM hb_language;
##########
REPLACE INTO `hb_language_locales` (`language_id`,`section`,`keyword`,`value`) SELECT id, 'countries', 'PF', 'French Polynesia' FROM hb_language;
##########
REPLACE INTO `hb_language_locales` (`language_id`,`section`,`keyword`,`value`) SELECT id, 'countries', 'TF', 'French Southern Territories' FROM hb_language;
##########
REPLACE INTO `hb_language_locales` (`language_id`,`section`,`keyword`,`value`) SELECT id, 'countries', 'GA', 'Gabon' FROM hb_language;
##########
REPLACE INTO `hb_language_locales` (`language_id`,`section`,`keyword`,`value`) SELECT id, 'countries', 'GM', 'Gambia' FROM hb_language;
##########
REPLACE INTO `hb_language_locales` (`language_id`,`section`,`keyword`,`value`) SELECT id, 'countries', 'GE', 'Georgia' FROM hb_language;
##########
REPLACE INTO `hb_language_locales` (`language_id`,`section`,`keyword`,`value`) SELECT id, 'countries', 'DE', 'Germany' FROM hb_language;
##########
REPLACE INTO `hb_language_locales` (`language_id`,`section`,`keyword`,`value`) SELECT id, 'countries', 'GH', 'Ghana' FROM hb_language;
##########
REPLACE INTO `hb_language_locales` (`language_id`,`section`,`keyword`,`value`) SELECT id, 'countries', 'GI', 'Gibraltar' FROM hb_language;
##########
REPLACE INTO `hb_language_locales` (`language_id`,`section`,`keyword`,`value`) SELECT id, 'countries', 'GR', 'Greece' FROM hb_language;
##########
REPLACE INTO `hb_language_locales` (`language_id`,`section`,`keyword`,`value`) SELECT id, 'countries', 'GL', 'Greenland' FROM hb_language;
##########
REPLACE INTO `hb_language_locales` (`language_id`,`section`,`keyword`,`value`) SELECT id, 'countries', 'GD', 'Grenada' FROM hb_language;
##########
REPLACE INTO `hb_language_locales` (`language_id`,`section`,`keyword`,`value`) SELECT id, 'countries', 'GP', 'Guadeloupe' FROM hb_language;
##########
REPLACE INTO `hb_language_locales` (`language_id`,`section`,`keyword`,`value`) SELECT id, 'countries', 'GU', 'Guam' FROM hb_language;
##########
REPLACE INTO `hb_language_locales` (`language_id`,`section`,`keyword`,`value`) SELECT id, 'countries', 'GT', 'Guatemala' FROM hb_language;
##########
REPLACE INTO `hb_language_locales` (`language_id`,`section`,`keyword`,`value`) SELECT id, 'countries', 'GG', 'Guernsey' FROM hb_language;
##########
REPLACE INTO `hb_language_locales` (`language_id`,`section`,`keyword`,`value`) SELECT id, 'countries', 'GN', 'Guinea' FROM hb_language;
##########
REPLACE INTO `hb_language_locales` (`language_id`,`section`,`keyword`,`value`) SELECT id, 'countries', 'GW', 'Guinea-Bissau' FROM hb_language;
##########
REPLACE INTO `hb_language_locales` (`language_id`,`section`,`keyword`,`value`) SELECT id, 'countries', 'GY', 'Guyana' FROM hb_language;
##########
REPLACE INTO `hb_language_locales` (`language_id`,`section`,`keyword`,`value`) SELECT id, 'countries', 'HT', 'Haiti' FROM hb_language;
##########
REPLACE INTO `hb_language_locales` (`language_id`,`section`,`keyword`,`value`) SELECT id, 'countries', 'HM', 'Heard Island & Mcdonald Islands' FROM hb_language;
##########
REPLACE INTO `hb_language_locales` (`language_id`,`section`,`keyword`,`value`) SELECT id, 'countries', 'VA', 'Holy See (Vatican City State)' FROM hb_language;
##########
REPLACE INTO `hb_language_locales` (`language_id`,`section`,`keyword`,`value`) SELECT id, 'countries', 'HN', 'Honduras' FROM hb_language;
##########
REPLACE INTO `hb_language_locales` (`language_id`,`section`,`keyword`,`value`) SELECT id, 'countries', 'HK', 'Hong Kong' FROM hb_language;
##########
REPLACE INTO `hb_language_locales` (`language_id`,`section`,`keyword`,`value`) SELECT id, 'countries', 'HU', 'Hungary' FROM hb_language;
##########
REPLACE INTO `hb_language_locales` (`language_id`,`section`,`keyword`,`value`) SELECT id, 'countries', 'IS', 'Iceland' FROM hb_language;
##########
REPLACE INTO `hb_language_locales` (`language_id`,`section`,`keyword`,`value`) SELECT id, 'countries', 'IN', 'India' FROM hb_language;
##########
REPLACE INTO `hb_language_locales` (`language_id`,`section`,`keyword`,`value`) SELECT id, 'countries', 'ID', 'Indonesia' FROM hb_language;
##########
REPLACE INTO `hb_language_locales` (`language_id`,`section`,`keyword`,`value`) SELECT id, 'countries', 'IR', 'Iran, Islamic Republic Of' FROM hb_language;
##########
REPLACE INTO `hb_language_locales` (`language_id`,`section`,`keyword`,`value`) SELECT id, 'countries', 'IQ', 'Iraq' FROM hb_language;
##########
REPLACE INTO `hb_language_locales` (`language_id`,`section`,`keyword`,`value`) SELECT id, 'countries', 'IE', 'Ireland' FROM hb_language;
##########
REPLACE INTO `hb_language_locales` (`language_id`,`section`,`keyword`,`value`) SELECT id, 'countries', 'IM', 'Isle Of Man' FROM hb_language;
##########
REPLACE INTO `hb_language_locales` (`language_id`,`section`,`keyword`,`value`) SELECT id, 'countries', 'IL', 'Israel' FROM hb_language;
##########
REPLACE INTO `hb_language_locales` (`language_id`,`section`,`keyword`,`value`) SELECT id, 'countries', 'IT', 'Italy' FROM hb_language;
##########
REPLACE INTO `hb_language_locales` (`language_id`,`section`,`keyword`,`value`) SELECT id, 'countries', 'JM', 'Jamaica' FROM hb_language;
##########
REPLACE INTO `hb_language_locales` (`language_id`,`section`,`keyword`,`value`) SELECT id, 'countries', 'JP', 'Japan' FROM hb_language;
##########
REPLACE INTO `hb_language_locales` (`language_id`,`section`,`keyword`,`value`) SELECT id, 'countries', 'JE', 'Jersey' FROM hb_language;
##########
REPLACE INTO `hb_language_locales` (`language_id`,`section`,`keyword`,`value`) SELECT id, 'countries', 'JO', 'Jordan' FROM hb_language;
##########
REPLACE INTO `hb_language_locales` (`language_id`,`section`,`keyword`,`value`) SELECT id, 'countries', 'KZ', 'Kazakhstan' FROM hb_language;
##########
REPLACE INTO `hb_language_locales` (`language_id`,`section`,`keyword`,`value`) SELECT id, 'countries', 'KE', 'Kenya' FROM hb_language;
##########
REPLACE INTO `hb_language_locales` (`language_id`,`section`,`keyword`,`value`) SELECT id, 'countries', 'KI', 'Kiribati' FROM hb_language;
##########
REPLACE INTO `hb_language_locales` (`language_id`,`section`,`keyword`,`value`) SELECT id, 'countries', 'KR', 'Korea' FROM hb_language;
##########
REPLACE INTO `hb_language_locales` (`language_id`,`section`,`keyword`,`value`) SELECT id, 'countries', 'KW', 'Kuwait' FROM hb_language;
##########
REPLACE INTO `hb_language_locales` (`language_id`,`section`,`keyword`,`value`) SELECT id, 'countries', 'KG', 'Kyrgyzstan' FROM hb_language;
##########
REPLACE INTO `hb_language_locales` (`language_id`,`section`,`keyword`,`value`) SELECT id, 'countries', 'LA', 'Lao People\'s Democratic Republic' FROM hb_language;
##########
REPLACE INTO `hb_language_locales` (`language_id`,`section`,`keyword`,`value`) SELECT id, 'countries', 'LV', 'Latvia' FROM hb_language;
##########
REPLACE INTO `hb_language_locales` (`language_id`,`section`,`keyword`,`value`) SELECT id, 'countries', 'LB', 'Lebanon' FROM hb_language;
##########
REPLACE INTO `hb_language_locales` (`language_id`,`section`,`keyword`,`value`) SELECT id, 'countries', 'LS', 'Lesotho' FROM hb_language;
##########
REPLACE INTO `hb_language_locales` (`language_id`,`section`,`keyword`,`value`) SELECT id, 'countries', 'LR', 'Liberia' FROM hb_language;
##########
REPLACE INTO `hb_language_locales` (`language_id`,`section`,`keyword`,`value`) SELECT id, 'countries', 'LY', 'Libyan Arab Jamahiriya' FROM hb_language;
##########
REPLACE INTO `hb_language_locales` (`language_id`,`section`,`keyword`,`value`) SELECT id, 'countries', 'LI', 'Liechtenstein' FROM hb_language;
##########
REPLACE INTO `hb_language_locales` (`language_id`,`section`,`keyword`,`value`) SELECT id, 'countries', 'LT', 'Lithuania' FROM hb_language;
##########
REPLACE INTO `hb_language_locales` (`language_id`,`section`,`keyword`,`value`) SELECT id, 'countries', 'LU', 'Luxembourg' FROM hb_language;
##########
REPLACE INTO `hb_language_locales` (`language_id`,`section`,`keyword`,`value`) SELECT id, 'countries', 'MO', 'Macao' FROM hb_language;
##########
REPLACE INTO `hb_language_locales` (`language_id`,`section`,`keyword`,`value`) SELECT id, 'countries', 'MK', 'Macedonia' FROM hb_language;
##########
REPLACE INTO `hb_language_locales` (`language_id`,`section`,`keyword`,`value`) SELECT id, 'countries', 'MG', 'Madagascar' FROM hb_language;
##########
REPLACE INTO `hb_language_locales` (`language_id`,`section`,`keyword`,`value`) SELECT id, 'countries', 'MW', 'Malawi' FROM hb_language;
##########
REPLACE INTO `hb_language_locales` (`language_id`,`section`,`keyword`,`value`) SELECT id, 'countries', 'MY', 'Malaysia' FROM hb_language;
##########
REPLACE INTO `hb_language_locales` (`language_id`,`section`,`keyword`,`value`) SELECT id, 'countries', 'MV', 'Maldives' FROM hb_language;
##########
REPLACE INTO `hb_language_locales` (`language_id`,`section`,`keyword`,`value`) SELECT id, 'countries', 'ML', 'Mali' FROM hb_language;
##########
REPLACE INTO `hb_language_locales` (`language_id`,`section`,`keyword`,`value`) SELECT id, 'countries', 'MT', 'Malta' FROM hb_language;
##########
REPLACE INTO `hb_language_locales` (`language_id`,`section`,`keyword`,`value`) SELECT id, 'countries', 'MH', 'Marshall Islands' FROM hb_language;
##########
REPLACE INTO `hb_language_locales` (`language_id`,`section`,`keyword`,`value`) SELECT id, 'countries', 'MQ', 'Martinique' FROM hb_language;
##########
REPLACE INTO `hb_language_locales` (`language_id`,`section`,`keyword`,`value`) SELECT id, 'countries', 'MR', 'Mauritania' FROM hb_language;
##########
REPLACE INTO `hb_language_locales` (`language_id`,`section`,`keyword`,`value`) SELECT id, 'countries', 'MU', 'Mauritius' FROM hb_language;
##########
REPLACE INTO `hb_language_locales` (`language_id`,`section`,`keyword`,`value`) SELECT id, 'countries', 'YT', 'Mayotte' FROM hb_language;
##########
REPLACE INTO `hb_language_locales` (`language_id`,`section`,`keyword`,`value`) SELECT id, 'countries', 'MX', 'Mexico' FROM hb_language;
##########
REPLACE INTO `hb_language_locales` (`language_id`,`section`,`keyword`,`value`) SELECT id, 'countries', 'FM', 'Micronesia, Federated States Of' FROM hb_language;
##########
REPLACE INTO `hb_language_locales` (`language_id`,`section`,`keyword`,`value`) SELECT id, 'countries', 'MD', 'Moldova' FROM hb_language;
##########
REPLACE INTO `hb_language_locales` (`language_id`,`section`,`keyword`,`value`) SELECT id, 'countries', 'MC', 'Monaco' FROM hb_language;
##########
REPLACE INTO `hb_language_locales` (`language_id`,`section`,`keyword`,`value`) SELECT id, 'countries', 'MN', 'Mongolia' FROM hb_language;
##########
REPLACE INTO `hb_language_locales` (`language_id`,`section`,`keyword`,`value`) SELECT id, 'countries', 'ME', 'Montenegro' FROM hb_language;
##########
REPLACE INTO `hb_language_locales` (`language_id`,`section`,`keyword`,`value`) SELECT id, 'countries', 'MS', 'Montserrat' FROM hb_language;
##########
REPLACE INTO `hb_language_locales` (`language_id`,`section`,`keyword`,`value`) SELECT id, 'countries', 'MA', 'Morocco' FROM hb_language;
##########
REPLACE INTO `hb_language_locales` (`language_id`,`section`,`keyword`,`value`) SELECT id, 'countries', 'MZ', 'Mozambique' FROM hb_language;
##########
REPLACE INTO `hb_language_locales` (`language_id`,`section`,`keyword`,`value`) SELECT id, 'countries', 'MM', 'Myanmar' FROM hb_language;
##########
REPLACE INTO `hb_language_locales` (`language_id`,`section`,`keyword`,`value`) SELECT id, 'countries', 'NA', 'Namibia' FROM hb_language;
##########
REPLACE INTO `hb_language_locales` (`language_id`,`section`,`keyword`,`value`) SELECT id, 'countries', 'NR', 'Nauru' FROM hb_language;
##########
REPLACE INTO `hb_language_locales` (`language_id`,`section`,`keyword`,`value`) SELECT id, 'countries', 'NP', 'Nepal' FROM hb_language;
##########
REPLACE INTO `hb_language_locales` (`language_id`,`section`,`keyword`,`value`) SELECT id, 'countries', 'NL', 'Netherlands' FROM hb_language;
##########
REPLACE INTO `hb_language_locales` (`language_id`,`section`,`keyword`,`value`) SELECT id, 'countries', 'AN', 'Netherlands Antilles' FROM hb_language;
##########
REPLACE INTO `hb_language_locales` (`language_id`,`section`,`keyword`,`value`) SELECT id, 'countries', 'NC', 'New Caledonia' FROM hb_language;
##########
REPLACE INTO `hb_language_locales` (`language_id`,`section`,`keyword`,`value`) SELECT id, 'countries', 'NZ', 'New Zealand' FROM hb_language;
##########
REPLACE INTO `hb_language_locales` (`language_id`,`section`,`keyword`,`value`) SELECT id, 'countries', 'NI', 'Nicaragua' FROM hb_language;
##########
REPLACE INTO `hb_language_locales` (`language_id`,`section`,`keyword`,`value`) SELECT id, 'countries', 'NE', 'Niger' FROM hb_language;
##########
REPLACE INTO `hb_language_locales` (`language_id`,`section`,`keyword`,`value`) SELECT id, 'countries', 'NG', 'Nigeria' FROM hb_language;
##########
REPLACE INTO `hb_language_locales` (`language_id`,`section`,`keyword`,`value`) SELECT id, 'countries', 'NU', 'Niue' FROM hb_language;
##########
REPLACE INTO `hb_language_locales` (`language_id`,`section`,`keyword`,`value`) SELECT id, 'countries', 'NF', 'Norfolk Island' FROM hb_language;
##########
REPLACE INTO `hb_language_locales` (`language_id`,`section`,`keyword`,`value`) SELECT id, 'countries', 'MP', 'Northern Mariana Islands' FROM hb_language;
##########
REPLACE INTO `hb_language_locales` (`language_id`,`section`,`keyword`,`value`) SELECT id, 'countries', 'NO', 'Norway' FROM hb_language;
##########
REPLACE INTO `hb_language_locales` (`language_id`,`section`,`keyword`,`value`) SELECT id, 'countries', 'OM', 'Oman' FROM hb_language;
##########
REPLACE INTO `hb_language_locales` (`language_id`,`section`,`keyword`,`value`) SELECT id, 'countries', 'PK', 'Pakistan' FROM hb_language;
##########
REPLACE INTO `hb_language_locales` (`language_id`,`section`,`keyword`,`value`) SELECT id, 'countries', 'PW', 'Palau' FROM hb_language;
##########
REPLACE INTO `hb_language_locales` (`language_id`,`section`,`keyword`,`value`) SELECT id, 'countries', 'PS', 'Palestinian Territory, Occupied' FROM hb_language;
##########
REPLACE INTO `hb_language_locales` (`language_id`,`section`,`keyword`,`value`) SELECT id, 'countries', 'PA', 'Panama' FROM hb_language;
##########
REPLACE INTO `hb_language_locales` (`language_id`,`section`,`keyword`,`value`) SELECT id, 'countries', 'PG', 'Papua New Guinea' FROM hb_language;
##########
REPLACE INTO `hb_language_locales` (`language_id`,`section`,`keyword`,`value`) SELECT id, 'countries', 'PY', 'Paraguay' FROM hb_language;
##########
REPLACE INTO `hb_language_locales` (`language_id`,`section`,`keyword`,`value`) SELECT id, 'countries', 'PE', 'Peru' FROM hb_language;
##########
REPLACE INTO `hb_language_locales` (`language_id`,`section`,`keyword`,`value`) SELECT id, 'countries', 'PH', 'Philippines' FROM hb_language;
##########
REPLACE INTO `hb_language_locales` (`language_id`,`section`,`keyword`,`value`) SELECT id, 'countries', 'PN', 'Pitcairn' FROM hb_language;
##########
REPLACE INTO `hb_language_locales` (`language_id`,`section`,`keyword`,`value`) SELECT id, 'countries', 'PL', 'Poland' FROM hb_language;
##########
REPLACE INTO `hb_language_locales` (`language_id`,`section`,`keyword`,`value`) SELECT id, 'countries', 'PT', 'Portugal' FROM hb_language;
##########
REPLACE INTO `hb_language_locales` (`language_id`,`section`,`keyword`,`value`) SELECT id, 'countries', 'PR', 'Puerto Rico' FROM hb_language;
##########
REPLACE INTO `hb_language_locales` (`language_id`,`section`,`keyword`,`value`) SELECT id, 'countries', 'QA', 'Qatar' FROM hb_language;
##########
REPLACE INTO `hb_language_locales` (`language_id`,`section`,`keyword`,`value`) SELECT id, 'countries', 'RE', 'Reunion' FROM hb_language;
##########
REPLACE INTO `hb_language_locales` (`language_id`,`section`,`keyword`,`value`) SELECT id, 'countries', 'RO', 'Romania' FROM hb_language;
##########
REPLACE INTO `hb_language_locales` (`language_id`,`section`,`keyword`,`value`) SELECT id, 'countries', 'RU', 'Russian Federation' FROM hb_language;
##########
REPLACE INTO `hb_language_locales` (`language_id`,`section`,`keyword`,`value`) SELECT id, 'countries', 'RW', 'Rwanda' FROM hb_language;
##########
REPLACE INTO `hb_language_locales` (`language_id`,`section`,`keyword`,`value`) SELECT id, 'countries', 'BL', 'Saint Barthelemy' FROM hb_language;
##########
REPLACE INTO `hb_language_locales` (`language_id`,`section`,`keyword`,`value`) SELECT id, 'countries', 'SH', 'Saint Helena' FROM hb_language;
##########
REPLACE INTO `hb_language_locales` (`language_id`,`section`,`keyword`,`value`) SELECT id, 'countries', 'KN', 'Saint Kitts And Nevis' FROM hb_language;
##########
REPLACE INTO `hb_language_locales` (`language_id`,`section`,`keyword`,`value`) SELECT id, 'countries', 'LC', 'Saint Lucia' FROM hb_language;
##########
REPLACE INTO `hb_language_locales` (`language_id`,`section`,`keyword`,`value`) SELECT id, 'countries', 'MF', 'Saint Martin' FROM hb_language;
##########
REPLACE INTO `hb_language_locales` (`language_id`,`section`,`keyword`,`value`) SELECT id, 'countries', 'PM', 'Saint Pierre And Miquelon' FROM hb_language;
##########
REPLACE INTO `hb_language_locales` (`language_id`,`section`,`keyword`,`value`) SELECT id, 'countries', 'VC', 'Saint Vincent And Grenadines' FROM hb_language;
##########
REPLACE INTO `hb_language_locales` (`language_id`,`section`,`keyword`,`value`) SELECT id, 'countries', 'WS', 'Samoa' FROM hb_language;
##########
REPLACE INTO `hb_language_locales` (`language_id`,`section`,`keyword`,`value`) SELECT id, 'countries', 'SM', 'San Marino' FROM hb_language;
##########
REPLACE INTO `hb_language_locales` (`language_id`,`section`,`keyword`,`value`) SELECT id, 'countries', 'ST', 'Sao Tome And Principe' FROM hb_language;
##########
REPLACE INTO `hb_language_locales` (`language_id`,`section`,`keyword`,`value`) SELECT id, 'countries', 'SA', 'Saudi Arabia' FROM hb_language;
##########
REPLACE INTO `hb_language_locales` (`language_id`,`section`,`keyword`,`value`) SELECT id, 'countries', 'SN', 'Senegal' FROM hb_language;
##########
REPLACE INTO `hb_language_locales` (`language_id`,`section`,`keyword`,`value`) SELECT id, 'countries', 'RS', 'Serbia' FROM hb_language;
##########
REPLACE INTO `hb_language_locales` (`language_id`,`section`,`keyword`,`value`) SELECT id, 'countries', 'SC', 'Seychelles' FROM hb_language;
##########
REPLACE INTO `hb_language_locales` (`language_id`,`section`,`keyword`,`value`) SELECT id, 'countries', 'SL', 'Sierra Leone' FROM hb_language;
##########
REPLACE INTO `hb_language_locales` (`language_id`,`section`,`keyword`,`value`) SELECT id, 'countries', 'SG', 'Singapore' FROM hb_language;
##########
REPLACE INTO `hb_language_locales` (`language_id`,`section`,`keyword`,`value`) SELECT id, 'countries', 'SK', 'Slovakia' FROM hb_language;
##########
REPLACE INTO `hb_language_locales` (`language_id`,`section`,`keyword`,`value`) SELECT id, 'countries', 'SI', 'Slovenia' FROM hb_language;
##########
REPLACE INTO `hb_language_locales` (`language_id`,`section`,`keyword`,`value`) SELECT id, 'countries', 'SB', 'Solomon Islands' FROM hb_language;
##########
REPLACE INTO `hb_language_locales` (`language_id`,`section`,`keyword`,`value`) SELECT id, 'countries', 'SO', 'Somalia' FROM hb_language;
##########
REPLACE INTO `hb_language_locales` (`language_id`,`section`,`keyword`,`value`) SELECT id, 'countries', 'ZA', 'South Africa' FROM hb_language;
##########
REPLACE INTO `hb_language_locales` (`language_id`,`section`,`keyword`,`value`) SELECT id, 'countries', 'GS', 'South Georgia And Sandwich Isl.' FROM hb_language;
##########
REPLACE INTO `hb_language_locales` (`language_id`,`section`,`keyword`,`value`) SELECT id, 'countries', 'ES', 'Spain' FROM hb_language;
##########
REPLACE INTO `hb_language_locales` (`language_id`,`section`,`keyword`,`value`) SELECT id, 'countries', 'LK', 'Sri Lanka' FROM hb_language;
##########
REPLACE INTO `hb_language_locales` (`language_id`,`section`,`keyword`,`value`) SELECT id, 'countries', 'SD', 'Sudan' FROM hb_language;
##########
REPLACE INTO `hb_language_locales` (`language_id`,`section`,`keyword`,`value`) SELECT id, 'countries', 'SR', 'Suriname' FROM hb_language;
##########
REPLACE INTO `hb_language_locales` (`language_id`,`section`,`keyword`,`value`) SELECT id, 'countries', 'SJ', 'Svalbard And Jan Mayen' FROM hb_language;
##########
REPLACE INTO `hb_language_locales` (`language_id`,`section`,`keyword`,`value`) SELECT id, 'countries', 'SZ', 'Swaziland' FROM hb_language;
##########
REPLACE INTO `hb_language_locales` (`language_id`,`section`,`keyword`,`value`) SELECT id, 'countries', 'SE', 'Sweden' FROM hb_language;
##########
REPLACE INTO `hb_language_locales` (`language_id`,`section`,`keyword`,`value`) SELECT id, 'countries', 'CH', 'Switzerland' FROM hb_language;
##########
REPLACE INTO `hb_language_locales` (`language_id`,`section`,`keyword`,`value`) SELECT id, 'countries', 'SY', 'Syrian Arab Republic' FROM hb_language;
##########
REPLACE INTO `hb_language_locales` (`language_id`,`section`,`keyword`,`value`) SELECT id, 'countries', 'TW', 'Taiwan' FROM hb_language;
##########
REPLACE INTO `hb_language_locales` (`language_id`,`section`,`keyword`,`value`) SELECT id, 'countries', 'TJ', 'Tajikistan' FROM hb_language;
##########
REPLACE INTO `hb_language_locales` (`language_id`,`section`,`keyword`,`value`) SELECT id, 'countries', 'TZ', 'Tanzania' FROM hb_language;
##########
REPLACE INTO `hb_language_locales` (`language_id`,`section`,`keyword`,`value`) SELECT id, 'countries', 'TH', 'Thailand' FROM hb_language;
##########
REPLACE INTO `hb_language_locales` (`language_id`,`section`,`keyword`,`value`) SELECT id, 'countries', 'TL', 'Timor-Leste' FROM hb_language;
##########
REPLACE INTO `hb_language_locales` (`language_id`,`section`,`keyword`,`value`) SELECT id, 'countries', 'TG', 'Togo' FROM hb_language;
##########
REPLACE INTO `hb_language_locales` (`language_id`,`section`,`keyword`,`value`) SELECT id, 'countries', 'TK', 'Tokelau' FROM hb_language;
##########
REPLACE INTO `hb_language_locales` (`language_id`,`section`,`keyword`,`value`) SELECT id, 'countries', 'TO', 'Tonga' FROM hb_language;
##########
REPLACE INTO `hb_language_locales` (`language_id`,`section`,`keyword`,`value`) SELECT id, 'countries', 'TT', 'Trinidad And Tobago' FROM hb_language;
##########
REPLACE INTO `hb_language_locales` (`language_id`,`section`,`keyword`,`value`) SELECT id, 'countries', 'TN', 'Tunisia' FROM hb_language;
##########
REPLACE INTO `hb_language_locales` (`language_id`,`section`,`keyword`,`value`) SELECT id, 'countries', 'TR', 'Turkey' FROM hb_language;
##########
REPLACE INTO `hb_language_locales` (`language_id`,`section`,`keyword`,`value`) SELECT id, 'countries', 'TM', 'Turkmenistan' FROM hb_language;
##########
REPLACE INTO `hb_language_locales` (`language_id`,`section`,`keyword`,`value`) SELECT id, 'countries', 'TC', 'Turks And Caicos Islands' FROM hb_language;
##########
REPLACE INTO `hb_language_locales` (`language_id`,`section`,`keyword`,`value`) SELECT id, 'countries', 'TV', 'Tuvalu' FROM hb_language;
##########
REPLACE INTO `hb_language_locales` (`language_id`,`section`,`keyword`,`value`) SELECT id, 'countries', 'UG', 'Uganda' FROM hb_language;
##########
REPLACE INTO `hb_language_locales` (`language_id`,`section`,`keyword`,`value`) SELECT id, 'countries', 'UA', 'Ukraine' FROM hb_language;
##########
REPLACE INTO `hb_language_locales` (`language_id`,`section`,`keyword`,`value`) SELECT id, 'countries', 'AE', 'United Arab Emirates' FROM hb_language;
##########
REPLACE INTO `hb_language_locales` (`language_id`,`section`,`keyword`,`value`) SELECT id, 'countries', 'GB', 'United Kingdom' FROM hb_language;
##########
REPLACE INTO `hb_language_locales` (`language_id`,`section`,`keyword`,`value`) SELECT id, 'countries', 'US', 'United States' FROM hb_language;
##########
REPLACE INTO `hb_language_locales` (`language_id`,`section`,`keyword`,`value`) SELECT id, 'countries', 'UM', 'United States Outlying Islands' FROM hb_language;
##########
REPLACE INTO `hb_language_locales` (`language_id`,`section`,`keyword`,`value`) SELECT id, 'countries', 'UY', 'Uruguay' FROM hb_language;
##########
REPLACE INTO `hb_language_locales` (`language_id`,`section`,`keyword`,`value`) SELECT id, 'countries', 'UZ', 'Uzbekistan' FROM hb_language;
##########
REPLACE INTO `hb_language_locales` (`language_id`,`section`,`keyword`,`value`) SELECT id, 'countries', 'VU', 'Vanuatu' FROM hb_language;
##########
REPLACE INTO `hb_language_locales` (`language_id`,`section`,`keyword`,`value`) SELECT id, 'countries', 'VE', 'Venezuela' FROM hb_language;
##########
REPLACE INTO `hb_language_locales` (`language_id`,`section`,`keyword`,`value`) SELECT id, 'countries', 'VN', 'Viet Nam' FROM hb_language;
##########
REPLACE INTO `hb_language_locales` (`language_id`,`section`,`keyword`,`value`) SELECT id, 'countries', 'VG', 'Virgin Islands, British' FROM hb_language;
##########
REPLACE INTO `hb_language_locales` (`language_id`,`section`,`keyword`,`value`) SELECT id, 'countries', 'VI', 'Virgin Islands, U.S.' FROM hb_language;
##########
REPLACE INTO `hb_language_locales` (`language_id`,`section`,`keyword`,`value`) SELECT id, 'countries', 'WF', 'Wallis And Futuna' FROM hb_language;
##########
REPLACE INTO `hb_language_locales` (`language_id`,`section`,`keyword`,`value`) SELECT id, 'countries', 'EH', 'Western Sahara' FROM hb_language;
##########
REPLACE INTO `hb_language_locales` (`language_id`,`section`,`keyword`,`value`) SELECT id, 'countries', 'YE', 'Yemen' FROM hb_language;
##########
REPLACE INTO `hb_language_locales` (`language_id`,`section`,`keyword`,`value`) SELECT id, 'countries', 'ZM', 'Zambia' FROM hb_language;
##########
REPLACE INTO `hb_language_locales` (`language_id`,`section`,`keyword`,`value`) SELECT id, 'countries', 'ZW', 'Zimbabwe' FROM hb_language;
##########
REPLACE INTO `hb_language_locales` (`language_id`,`section`,`keyword`,`value`) SELECT id, 'global', 'nextinvoicetotal', 'Next invoice total' FROM hb_language;
##########
UPDATE `hb_email_templates` SET `message`='{$ticket.name},

Thank you for request. We will be in touch shortly.

SUBJECT: {$ticket.subject}

STATUS:
{$ticket.status}
{$ticket_url}

{if $ticket_attachments}
Following files have been attached:
{foreach from=$ticket_attachments item=attachment}
{$attachment.org_filename},
{/foreach}
{/if}

{if $ticket_attachments_errors}
Following Files: {foreach from=$ticket_attachments_errors item=attachment}{$attachment.org_filename},{/foreach} have been rejected.
Supported attachments extensions: {$attachments_ext}
{/if}' WHERE `tplname`='Ticket:New' AND `group`='Support' AND `for`='Client' LIMIT 1;
##########
UPDATE `hb_email_templates` SET `subject` = 'Notes for ticket: #{$ticket.ticket_number}  updated',
`message`='Notes has just been updated for ticket #{$ticket.ticket_number}

{if $notes}
{foreach from=$notes item=entry}
----------------------------------------------------------------
{$entry.date|dateformat:$date_format}
{if $entry.lastname!='' && $entry.firstname!=''}{$entry.firstname} {$entry.lastname}{else}{$entry.username}{/if}:  {$entry.note}
{/foreach}
----------------------------------------------------------------
{/if}


New note:
----------------------------------------------------------------
{$note.date|dateformat:$date_format}
{if $note.by.lastname!='' && $note.by.firstname!=''}{$note.by.firstname} {$note.by.lastname}{else}{$note.by.username}{/if}:  {$note.msg}

URL: {$ticket.url}' WHERE `tplname`='Ticket:Notes Change' AND `group`='Support' AND `for`='Admin' LIMIT 1;