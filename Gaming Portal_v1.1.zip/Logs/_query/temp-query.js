#query all connections listed below line 2
#query addresses must be external IP addresses only
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#max limit of query addresses reached at this line
