UPDATE `hb_configuration` SET `value` = '3.2.5' WHERE `setting`= 'Version';
##########
ALTER TABLE `hb_accounts` ENGINE=InnoDB;
##########
ALTER TABLE `hb_accounts_addons` ENGINE=InnoDB;
##########
ALTER TABLE `hb_account_logs` ENGINE=InnoDB;
##########
ALTER TABLE `hb_addons` ENGINE=InnoDB;
##########
ALTER TABLE `hb_addons_config` ENGINE=InnoDB;
##########
ALTER TABLE `hb_addons_modules` ENGINE=InnoDB;
##########
ALTER TABLE `hb_admin_access` ENGINE=InnoDB;
##########
ALTER TABLE `hb_admin_details` ENGINE=InnoDB;
##########
ALTER TABLE `hb_admin_log` ENGINE=InnoDB;
##########
ALTER TABLE `hb_aff` ENGINE=InnoDB;
##########
ALTER TABLE `hb_aff_orders` ENGINE=InnoDB;
##########
ALTER TABLE `hb_aff_widlog` ENGINE=InnoDB;
##########
ALTER TABLE `hb_annoucements` ENGINE=InnoDB;
##########
ALTER TABLE `hb_api_access` ENGINE=InnoDB;
##########
ALTER TABLE `hb_api_log` ENGINE=InnoDB;
##########
ALTER TABLE `hb_automation_settings` ENGINE=InnoDB;
##########
ALTER TABLE `hb_banned_emails` ENGINE=InnoDB;
##########
ALTER TABLE `hb_banned_ip` ENGINE=InnoDB;
##########
ALTER TABLE `hb_cancel_requests` ENGINE=InnoDB;
##########
ALTER TABLE `hb_categories` ENGINE=InnoDB;
##########
ALTER TABLE `hb_chat_canned_cat` ENGINE=InnoDB;
##########
ALTER TABLE `hb_chat_canned_fav` ENGINE=InnoDB;
##########
ALTER TABLE `hb_chat_canned_resp` ENGINE=InnoDB;
##########
ALTER TABLE `hb_chat_dept` ENGINE=InnoDB;
##########
ALTER TABLE `hb_chat_discussions2` ENGINE=InnoDB;
##########
ALTER TABLE `hb_chat_footprints` ENGINE=InnoDB;
##########
ALTER TABLE `hb_chat_images` ENGINE=InnoDB;
##########
ALTER TABLE `hb_chat_messages2` ENGINE=InnoDB;
##########
ALTER TABLE `hb_chat_staff2` ENGINE=InnoDB;
##########
ALTER TABLE `hb_chat_staff2dept` ENGINE=InnoDB;
##########
ALTER TABLE `hb_chat_visitor` ENGINE=InnoDB;
##########
ALTER TABLE `hb_chat_visitor_geodata` ENGINE=InnoDB;
##########
ALTER TABLE `hb_client_access` ENGINE=InnoDB;
##########
ALTER TABLE `hb_client_activity_log` ENGINE=InnoDB;
##########
ALTER TABLE `hb_client_billing` ENGINE=InnoDB;
##########
ALTER TABLE `hb_client_details` ENGINE=InnoDB;
##########
ALTER TABLE `hb_client_fields` ENGINE=InnoDB;
##########
ALTER TABLE `hb_client_fields_values` ENGINE=InnoDB;
##########
ALTER TABLE `hb_client_privileges` ENGINE=InnoDB;
##########
ALTER TABLE `hb_common` ENGINE=InnoDB;
##########
ALTER TABLE `hb_config2accounts` ENGINE=InnoDB;
##########
ALTER TABLE `hb_configuration` ENGINE=InnoDB;
##########
ALTER TABLE `hb_config_items` ENGINE=InnoDB;
##########
ALTER TABLE `hb_config_items_cat` ENGINE=InnoDB;
##########
ALTER TABLE `hb_config_items_types` ENGINE=InnoDB;
##########
ALTER TABLE `hb_config_upgrades` ENGINE=InnoDB;
##########
ALTER TABLE `hb_coupons` ENGINE=InnoDB;
##########
ALTER TABLE `hb_coupons_log` ENGINE=InnoDB;
##########
ALTER TABLE `hb_cron_profiles` ENGINE=InnoDB;
##########
ALTER TABLE `hb_cron_tasks` ENGINE=InnoDB;
##########
ALTER TABLE `hb_currencies` ENGINE=InnoDB;
##########
ALTER TABLE `hb_dnsconfig` ENGINE=InnoDB;
##########
ALTER TABLE `hb_dnsdomains` ENGINE=InnoDB;
##########
ALTER TABLE `hb_dnslogs` ENGINE=InnoDB;
##########
ALTER TABLE `hb_domains` ENGINE=InnoDB;
##########
ALTER TABLE `hb_domain_logs` ENGINE=InnoDB;
##########
ALTER TABLE `hb_domain_periods` ENGINE=InnoDB;
##########
ALTER TABLE `hb_domain_prices` ENGINE=InnoDB;
##########
ALTER TABLE `hb_downloads` ENGINE=InnoDB;
##########
ALTER TABLE `hb_downloads_cats` ENGINE=InnoDB;
##########
ALTER TABLE `hb_email_assign` ENGINE=InnoDB;
##########
ALTER TABLE `hb_email_log` ENGINE=InnoDB;
##########
ALTER TABLE `hb_email_templates` ENGINE=InnoDB;
##########
ALTER TABLE `hb_email_templates_lang` ENGINE=InnoDB;
##########
ALTER TABLE `hb_estimates` ENGINE=InnoDB;
##########
ALTER TABLE `hb_estimate_items` ENGINE=InnoDB;
##########
ALTER TABLE `hb_fraud_output` ENGINE=InnoDB;
##########
ALTER TABLE `hb_gateway_log` ENGINE=InnoDB;
##########
ALTER TABLE `hb_geoip_block_0` ENGINE=InnoDB;
##########
ALTER TABLE `hb_geoip_block_1` ENGINE=InnoDB;
##########
ALTER TABLE `hb_geoip_block_2` ENGINE=InnoDB;
##########
ALTER TABLE `hb_geoip_block_3` ENGINE=InnoDB;
##########
ALTER TABLE `hb_geoip_block_4` ENGINE=InnoDB;
##########
ALTER TABLE `hb_geoip_block_5` ENGINE=InnoDB;
##########
ALTER TABLE `hb_geoip_block_6` ENGINE=InnoDB;
##########
ALTER TABLE `hb_geoip_block_7` ENGINE=InnoDB;
##########
ALTER TABLE `hb_geoip_cities` ENGINE=InnoDB;
##########
ALTER TABLE `hb_infopages` ENGINE=InnoDB;
##########
ALTER TABLE `hb_invoices` ENGINE=InnoDB;
##########
ALTER TABLE `hb_invoice_items` ENGINE=InnoDB;
##########
ALTER TABLE `hb_knowledgebase` ENGINE=InnoDB;
##########
ALTER TABLE `hb_knowledgebase_cat` ENGINE=InnoDB;
##########
ALTER TABLE `hb_language` ENGINE=InnoDB;
##########
ALTER TABLE `hb_language_locales` ENGINE=InnoDB;
##########
ALTER TABLE `hb_mettered_prices` ENGINE=InnoDB;
##########
ALTER TABLE `hb_mettered_reports` ENGINE=InnoDB;
##########
ALTER TABLE `hb_mettered_values` ENGINE=InnoDB;
##########
ALTER TABLE `hb_mettered_variables` ENGINE=InnoDB;
##########
ALTER TABLE `hb_modules_configuration` ENGINE=InnoDB;
##########
ALTER TABLE `hb_orders` ENGINE=InnoDB;
##########
ALTER TABLE `hb_products` ENGINE=InnoDB;
##########
ALTER TABLE `hb_products_freetlds` ENGINE=InnoDB;
##########
ALTER TABLE `hb_products_modules` ENGINE=InnoDB;
##########
ALTER TABLE `hb_product_types` ENGINE=InnoDB;
##########
ALTER TABLE `hb_recurring_invoices` ENGINE=InnoDB;
##########
ALTER TABLE `hb_security_rules` ENGINE=InnoDB;
##########
ALTER TABLE `hb_servers` ENGINE=InnoDB;
##########
ALTER TABLE `hb_server_groups` ENGINE=InnoDB;
##########
ALTER TABLE `hb_subproducts` ENGINE=InnoDB;
##########
ALTER TABLE `hb_subscription_items` ENGINE=InnoDB;
##########
ALTER TABLE `hb_system_log` ENGINE=InnoDB;
##########
ALTER TABLE `hb_tags` ENGINE=InnoDB;
##########
ALTER TABLE `hb_task_list` ENGINE=InnoDB;
##########
ALTER TABLE `hb_task_log` ENGINE=InnoDB;
##########
ALTER TABLE `hb_tax` ENGINE=InnoDB;
##########
ALTER TABLE `hb_templates` ENGINE=InnoDB;
##########
ALTER TABLE `hb_template_content` ENGINE=InnoDB;
##########
ALTER TABLE `hb_tickets` ENGINE=InnoDB;
##########
ALTER TABLE `hb_tickets_attachments` ENGINE=InnoDB;
##########
ALTER TABLE `hb_tickets_bans` ENGINE=InnoDB;
##########
ALTER TABLE `hb_tickets_emails` ENGINE=InnoDB;
##########
ALTER TABLE `hb_tickets_log` ENGINE=InnoDB;
##########
ALTER TABLE `hb_tickets_notes` ENGINE=InnoDB;
##########
ALTER TABLE `hb_tickets_predefinied` ENGINE=InnoDB;
##########
ALTER TABLE `hb_tickets_predefinied_cats` ENGINE=InnoDB;
##########
ALTER TABLE `hb_tickets_predefinied_my` ENGINE=InnoDB;
##########
ALTER TABLE `hb_tickets_tags` ENGINE=InnoDB;
##########
ALTER TABLE `hb_ticket_departments` ENGINE=InnoDB;
##########
ALTER TABLE `hb_ticket_replies` ENGINE=InnoDB;
##########
ALTER TABLE `hb_transactions` ENGINE=InnoDB;
##########
ALTER TABLE `hb_upgrades` ENGINE=InnoDB;
##########
ALTER TABLE `hb_vps_details` ENGINE=InnoDB;
##########
ALTER TABLE `hb_widgets` ENGINE=InnoDB;
##########
ALTER TABLE `hb_widgets_config` ENGINE=InnoDB;
##########